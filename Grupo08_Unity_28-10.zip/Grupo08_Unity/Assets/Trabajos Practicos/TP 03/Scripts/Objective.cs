using UnityEngine;

namespace TP03.Objectives
{
    [System.Serializable]
    public class Objective
    {
        [TextArea] public string description;
    }
}
