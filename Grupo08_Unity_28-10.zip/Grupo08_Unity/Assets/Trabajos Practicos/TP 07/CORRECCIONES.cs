// Tiene que heredar del Arbol bst del tp 06, agragandole lo necesario para que este balanceado. Fijarme en el tp 12 anterior donde herede para hacer
//lo mismo. 

// Tiene que poder agregar puntajes nuevos. Nose si random o escribiendolos.