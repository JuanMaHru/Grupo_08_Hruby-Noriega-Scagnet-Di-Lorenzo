using UnityEngine;
using TMPro;

public class InventoryUI : MonoBehaviour
{
    [Header("Referencias")]
    [SerializeField] private PlayerInventory playerInv;
    [SerializeField] private Wallet wallet;
    [SerializeField] private ItemSlotUI[] slots;
    [SerializeField] private TMP_Text feedbackText;

    private void OnEnable()
    {
        Redibujar();
    }

    public void Redibujar()
    {
        var entries = playerInv.GetEntries();
        int i = 0;

        foreach (var entry in entries)
        {
            if (i >= slots.Length) break;

            var slot = slots[i];
            slot.SetData(entry.Item, entry.Cantidad);
            slot.OnLeftClick = _ => MostrarFeedback("Click derecho para vender.");
            slot.OnRightClick = Vender;
            i++;
        }

        for (; i < slots.Length; i++)
        {
            slots[i].SetData(null);
            slots[i].OnLeftClick = null;
            slots[i].OnRightClick = null;
        }
    }

    private void Vender(Item item)
    {
        Debug.Log("Intentando vender: " + item.Nombre);

        if (!playerInv.Quitar(item, 1))
        {
            MostrarFeedback("No ten�s ese �tem.");
            return;
        }

        int precioVenta = Mathf.Max(1, item.Precio / 2);
        wallet.Cobrar(precioVenta);
        MostrarFeedback($"Vendiste {item.Nombre} por ${precioVenta}.");
        Redibujar();
    }

    private void MostrarFeedback(string msg)
    {
        if (feedbackText) feedbackText.text = msg;
    }
}
