using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;
using TMPro;

public class ItemSlotUI : MonoBehaviour, IPointerClickHandler
{
    [Header("Referencias UI")]
    [SerializeField] private Image icon;
    [SerializeField] private TMP_Text nameText;
    [SerializeField] private TMP_Text priceText;
    [SerializeField] private TMP_Text qtyText; // opcional para inventario

    public Item Item { get; private set; }

    public System.Action<Item> OnLeftClick;
    public System.Action<Item> OnRightClick;

    public void SetData(Item item, int? cantidad = null)
    {
        Item = item;

        if (item == null)
        {
            if (icon) icon.sprite = null;
            if (nameText) nameText.text = "";
            if (priceText) priceText.text = "";
            if (qtyText) qtyText.text = "";
            return;
        }

        if (icon) icon.sprite = item.Sprite;
        if (nameText) nameText.text = item.Nombre;
        if (priceText) priceText.text = "$" + item.Precio;
        if (qtyText) qtyText.text = cantidad.HasValue ? "x" + cantidad.Value : "";
    }

    public void OnPointerClick(PointerEventData eventData)
    {
        if (Item == null) return;

        if (eventData.button == PointerEventData.InputButton.Left)
            OnLeftClick?.Invoke(Item);
        else if (eventData.button == PointerEventData.InputButton.Right)
            OnRightClick?.Invoke(Item);
    }
}
