using UnityEngine;
using TMPro;

public class StoreUI : MonoBehaviour
{
    [Header("Referencias L�gicas")]
    [SerializeField] private Store store;
    [SerializeField] private Wallet wallet;
    [SerializeField] private PlayerInventory playerInv;
    [SerializeField] private InventoryUI inventoryUI; // para refrescar inventario tras comprar

    [Header("Slots Tienda (GameObjects en escena)")]
    [SerializeField] private ItemSlotUI[] slots;
    [SerializeField] private TMP_Text moneyText;
    [SerializeField] private TMP_Text feedbackText;

    private void Start()
    {
        wallet.MoneyChanged += OnMoneyChanged;
        OnMoneyChanged(wallet.Dinero);

        var items = store.GetItems();
        int i = 0;
        foreach (var item in items)
        {
            if (i >= slots.Length) break;

            var slot = slots[i];
            slot.SetData(item);
            slot.OnLeftClick = OnComprarClick;
            slot.OnRightClick = _ => MostrarFeedback("Us� click izquierdo para comprar.");
            i++;
        }
    }

    private void OnDestroy()
    {
        if (wallet != null) wallet.MoneyChanged -= OnMoneyChanged;
    }

    private void OnMoneyChanged(int nuevoValor)
    {
        if (moneyText) moneyText.text = "$ " + nuevoValor;
    }

    private void OnComprarClick(Item item)
    {
        if (!wallet.PuedePagar(item.Precio))
        {
            MostrarFeedback("Dinero insuficiente.");
            return;
        }

        wallet.Pagar(item.Precio);
        playerInv.Agregar(item, 1);
        MostrarFeedback($"Compraste {item.Nombre} por ${item.Precio}.");
        inventoryUI?.Redibujar();
    }

    private void MostrarFeedback(string msg)
    {
        if (feedbackText) feedbackText.text = msg;
    }
}
